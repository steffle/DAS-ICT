package ppcJobMonitor;

import junit.framework.TestCase;
import ppcJobMonitor.Model.DataAccess;
import ppcJobMonitor.Model.MsgConstructorFinished;

public class TestMsgConstructorFinished extends TestCase {
	private MsgConstructorFinished mcf;
	private DataAccess da;

	public TestMsgConstructorFinished(String name) {
		super(name);
	}

	protected void setUp() throws Exception {
		super.setUp();
		da = new DataAccess();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
		da = null;
	}

	public void testMsgConstructorFinishedYHS() {
		mcf = new MsgConstructorFinished(da, "C:\\local\\varLogPeakwork\\LOC\\loc2\\playercontrols", 319924, "YHS",
				"Package", "YHS", 1484827999, "ch01s7f7");
		mcf.createAlert("Test", "HEAD", "Body");
		assertEquals(101, mcf.getPlayerCfgId());
	}

	public void testMsgConstructorFinishedYITHEXT() {
		mcf = new MsgConstructorFinished(da, "C:\\local\\varLogPeakwork\\LOC\\loc2\\playercontrols", 332588, "YITHEXT",
				"HotelOnly", "YITHEXT_2", 1484826000, "ch01s7f7");
		assertEquals(11091, mcf.getTotalObjects());
		assertEquals("YITHEXT", mcf.getBrand());
		assertEquals("HotelOnly", mcf.getDatatype());
	}

	public void testMsgConstructorFinishedCHPTRHO() {
		mcf = new MsgConstructorFinished(da, "C:\\local\\varLogPeakwork\\LOC\\loc1\\playercontrols", 1637610, "CHPTR",
				"HotelOnly", "CHPTRHO", 1486978359, "ch01s7f7");
		assertEquals(5840, mcf.getTotalObjects());
		assertEquals("CHPTR", mcf.getBrand());
		assertEquals("HotelOnly", mcf.getDatatype());
		assertEquals(1486978359, mcf.getJobEnd());
	}
}
