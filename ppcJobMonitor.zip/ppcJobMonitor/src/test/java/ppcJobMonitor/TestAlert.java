package ppcJobMonitor;

import java.util.HashSet;

import junit.framework.TestCase;
import ppcJobMonitor.Control.Alert;
import ppcJobMonitor.Model.DataAccess;

public class TestAlert extends TestCase {
	private DataAccess da;
	private Alert alert;

	public TestAlert(String name) {
		super(name);
	}

	protected void setUp() throws Exception {
		super.setUp();
		da = new DataAccess();
		alert = new Alert();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
		da = null;
		alert = null;
	}

	/**
	 * Check alerts manually
	 */
	public void testProcessList() {
		HashSet<String> recipients = (da.getRecipients(281));
		if (!recipients.isEmpty()) {
			alert.processRecipientList(recipients, "testProcessList", "head: testProcessList", "testProcessList body");
		}
	}

	/**
	 * Check alert manually
	 */
	public void testSendHtml() {
		alert.sendHtml("stefan.flepp@hotelplan.com", "Test Mail", "Test Mail Head", "Test Mail Body");
	}
}
