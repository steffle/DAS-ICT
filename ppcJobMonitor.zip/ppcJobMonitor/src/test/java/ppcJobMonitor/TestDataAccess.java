/**
 * 
 */
package ppcJobMonitor;

import java.util.HashSet;
import junit.framework.TestCase;
import ppcJobMonitor.Model.DataAccess;

/**
 * @author sflepp
 *
 */
public class TestDataAccess extends TestCase {
	private DataAccess da;

	/**
	 * @param name
	 */
	public TestDataAccess(String name) {
		super(name);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		da = new DataAccess();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see junit.framework.TestCase#tearDown()
	 */
	protected void tearDown() throws Exception {
		super.tearDown();
		da = null;
	}

	public void testGetDatatypeAsString() {
		assertEquals("Package", da.getDatatypeAsString(3));
		assertEquals("FlightOnly", da.getDatatypeAsString(2));
		assertEquals("HotelOnly", da.getDatatypeAsString(1));
	}

	public void testGetLogPathes() {
		HashSet<String> testSet = new HashSet<String>();

		testSet.add("/var/exports/prod/ch01s7c8/playercontrols");
		testSet.add("/var/exports/prod/ch01s7c7/playercontrols");
		testSet.add("/var/exports/prod/ch01s7c9/playercontrols");
		assertEquals(testSet, da.getLogPathes());
	}

	public void testGetPathFromPpc() {
		assertEquals("C:\\\\local\\\\varLogPeakwork\\\\LOC\\\\loc2\\\\playercontrols", da.getPathFromPpc("cm00w025-2"));
	}

	public void testGetEnvIdFromPpc() {
		assertEquals(12, da.getEnvIdFromPpc("ch01s7f7"));
	}

	public void testGetAmqForEnabledEnvs() {
		HashSet<String> amqHosts = new HashSet<String>();
		amqHosts.add("ch01s7c1.hotelplan.net");
		assertEquals(amqHosts, da.getAmqForEnabledEnvs());
	}

	public void testGetLastHistTimestamp() {
		// PlayerCfgId 119 = CHNEUT HO
		assertEquals(1486294475, da.getLastHistTimestamp(119));
	}

	public void testGetPlayerCfgIdIntInt() {
		// 59 CHNEUT, 12 Test-Env
		assertEquals(119, da.getPlayerCfgId(59, 12));
	}

	public void testGetPlayerCfgIdStringStringInt() {
		assertEquals(119, da.getPlayerCfgId("CHNEUT", "HotelOnly", 12));
	}

	public void testGetPlayerId() {
		assertEquals(119, da.getPlayerCfgId("CHNEUT", "HotelOnly", 12));
	}

	public void testGetLastJobResult() {
		// PlayerCfgId 119 = CHNEUT HO
		assertEquals(8111, da.getLastJobResult(88));
	}

	public void testGetLowerLimit() {
		assertEquals(80, da.getLowerLimit(281));
	}

	public void testGetUpperLimit() {
		assertEquals(120, da.getUpperLimit(281));
	}

	public void testGetRecipients() {
		assertNotNull(da.getRecipients(281));
	}
}
