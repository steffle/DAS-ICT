/**
 * 
 */
package ppcJobMonitor;

import java.util.HashMap;

import junit.framework.TestCase;
import ppcJobMonitor.Control.MessageWorker;
import ppcJobMonitor.Model.DataAccess;

/**
 * @author sflepp
 *
 */
public class TestMessageWorker extends TestCase {
	private DataAccess da;

	/**
	 * @param name
	 */
	public TestMessageWorker(String name) {
		super(name);
	}

	protected void setUp() throws Exception {
		super.setUp();
		da = new DataAccess();

	}

	protected void tearDown() throws Exception {
		super.tearDown();
		da = null;
	}

	public void testMessageParsePackage() {
		String msg = "ts,1484303500;host,cm00w025-2;appID,PPC_PROD_1303;environmentID,;msg,201;id,319924;tourop,;brand,YHS;dt,3;subid,;cat,;modulename,YHS;dependencies,;extid,0";
		MessageWorker mw = new MessageWorker(msg, da);
		HashMap<String, String> map = mw.messageParse(msg);
		assertEquals("YHS", map.get("brand"));
		assertEquals("3", map.get("dt"));
		assertEquals("Package", da.getDatatypeAsString(Integer.decode(map.get("dt"))));
		assertEquals("1484303500", map.get("ts"));
		assertEquals("319924", map.get("id"));
		assertEquals("cm00w025-2", map.get("host"));
		mw = null;
	}

	public void testMessageParseHotelOnly() {
		String msg = "ts,1484310980;host,cm00w025-2;appID,PPC_PROD_1304;environmentID,;msg,201;id,1594928;tourop,;brand,YBFH;dt,1;subid,;cat,;modulename,YBFH_2;dependencies,;extid,0";
		MessageWorker mw = new MessageWorker(msg, da);
		HashMap<String, String> map = mw.messageParse(msg);
		assertEquals("YBFH", map.get("brand"));
		assertEquals("1", map.get("dt"));
		assertEquals("HotelOnly", da.getDatatypeAsString(Integer.decode(map.get("dt"))));
		assertEquals("1484310980", map.get("ts"));
		assertEquals("1594928", map.get("id"));
		assertEquals("cm00w025-2", map.get("host"));
		mw = null;
	}

}
