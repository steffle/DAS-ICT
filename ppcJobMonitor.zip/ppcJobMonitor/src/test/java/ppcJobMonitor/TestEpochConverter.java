package ppcJobMonitor;

import junit.framework.TestCase;
import ppcJobMonitor.Model.EpochConverter;

public class TestEpochConverter extends TestCase {

	public TestEpochConverter(String name) {
		super(name);
	}

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testEpochToString() {
		assertEquals("2017-01-22 08:24:48", EpochConverter.epochToString(1485069888));
	}
}
