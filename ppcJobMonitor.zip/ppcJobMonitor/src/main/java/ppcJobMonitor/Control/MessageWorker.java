package ppcJobMonitor.Control;

import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ppcJobMonitor.Model.DataAccess;
import ppcJobMonitor.Model.MsgConstructorFinished;

/**
 * Class process incoming messages and compare the actual value with the
 * historical value, set the actual value in db and raise an alert if needed
 * 
 * @author sflepp
 * @version 1.0.15
 * 
 */
public class MessageWorker {
	private static final Logger LOG = LoggerFactory.getLogger(MessageWorker.class);
	private HashMap<String, String> parsedMsg;
	private DataAccess dataAccess;

	/**
	 * @param msg
	 * @param dataAccess
	 */
	public MessageWorker(String msg, DataAccess dataAccess) {
		parsedMsg = new HashMap<String, String>();
		this.dataAccess = dataAccess;
		processMsg(msg);
	}

	/**
	 * Method get the msg number and convert datatype from int to String, call
	 * method for processing message
	 * 
	 * @param msg
	 */
	public void processMsg(String msg) {
		parsedMsg = messageParse(msg);
		String path = (dataAccess.getPathFromPpc(parsedMsg.get("host")));
		int jobId = (Integer.parseInt(parsedMsg.get("id")));
		String brand = (parsedMsg.get("brand"));
		String datatype = (dataAccess.getDatatypeAsString(Integer.decode(parsedMsg.get("dt"))));
		String modulename = (parsedMsg.get("modulename"));
		int jobEnd = (Integer.parseInt(parsedMsg.get("ts")));
		String ppcHost = parsedMsg.get("host");
		int msgnr = Integer.decode(parsedMsg.get("msg"));
		// only Msg with number 201 and datatype "HotelOnly" are proceeded
		if (msgnr == 201 && !datatype.equals("FlightOnly")) {
			LOG.debug(
					"Call of MsgConstructorFinished with Parameter:\njobId=" + jobId + " brand=" + brand + " datatype="
							+ datatype + " modulename=" + modulename + " jobEnd=" + jobEnd + " ppcHost=" + ppcHost);
			new MsgConstructorFinished(dataAccess, path, jobId, brand, datatype, modulename, jobEnd, ppcHost);
		}
	}

	/**
	 * Method split incoming message String in a HashMap (String to String[] to
	 * HashMap<String, String>
	 * 
	 * @param msg
	 * @return parsed message as HashMap<String, String>
	 */

	public HashMap<String, String> messageParse(String msg) {
		HashMap<String, String> msgParts = null;
		try {
			msgParts = new HashMap<String, String>();
			String[] pairs;
			pairs = msg.split(";");
			for (String e : pairs) {
				String[] keyvalue = (e.split(","));
				// check is key/value pair not null and key and value exists
				if (keyvalue != null && keyvalue.length == 2) {
					msgParts.put(keyvalue[0], keyvalue[1]);
				}
			}
		} catch (Exception e) {
			LOG.error("Error getting key values pairs from: " + msg + " " + e.getMessage());
			e.printStackTrace();
		}
		return msgParts;
	}
}
