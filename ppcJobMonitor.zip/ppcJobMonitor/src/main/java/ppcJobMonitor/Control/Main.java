package ppcJobMonitor.Control;

import java.util.HashSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ppcJobMonitor.Model.DataAccess;
import ppcJobMonitor.Model.EpochConverter;
import ppcJobMonitor.Model.Observer;

/**
 * Class starts the application
 * 
 * @author sflepp
 * @version 1.0.5
 */
public class Main implements Observer {
	private static final Logger LOG = LoggerFactory.getLogger(Main.class);
	private DataAccess dataAccess;

	public Main() {
		dataAccess = new DataAccess();
	}

	public static void main(String[] args) {
		Main main = new Main();
		main.start();
	}

	/**
	 * setup the needed threads
	 */
	public void start() {
		HashSet<String> amqHosts = new HashSet<String>();
		amqHosts = dataAccess.getAmqForEnabledEnvs();
		if (!amqHosts.isEmpty()) {
			for (String e : amqHosts) {
				setupAmqProcessor(e, "Constructor");
			}
		}
		startNfsChk();
		LOG.info("ppcJobMonitor started - " + EpochConverter.nowFormated());
	}

	/**
	 * Setup and start the AmqMessageProzessor class
	 * 
	 * @param threadName
	 * @param amqhost
	 * @param topic
	 */
	public void setupAmqProcessor(String amqhost, String topic) {
		AmqMessageProzessor amp = new AmqMessageProzessor(amqhost, topic);
		amp.addObserverToConsumer(this);
	}

	/**
	 * start the CheckNFS class
	 */
	public void startNfsChk() {
		new CheckNfs(dataAccess);

	}

	/**
	 * Process the update from interface observer
	 */
	public void update(String msg) {
		new MessageWorker(msg, dataAccess);
	}

}
