package ppcJobMonitor.Control;

import java.util.HashSet;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class for sending alerts
 * 
 * @author sflepp
 * @version 1.0.2
 */
public class Alert {
	private static final Logger LOG = LoggerFactory.getLogger(Alert.class);
	private static final String FROM = "pwmon-do-not-reply@hotelplan.net";
	private static final String HOST = "mail.hotelplan.net";
	private Session session;

	public Alert() {
		// Get system properties
		Properties properties = System.getProperties();

		// Setup mail server
		properties.setProperty("mail.smtp.host", HOST);

		// Get the default Session object.
		session = Session.getDefaultInstance(properties);
	}

	/**
	 * Method process a list of recipients to method dispatchRecipientTyp
	 * 
	 * @param recipients
	 * @param subject
	 * @param head
	 * @param body
	 */
	public void processRecipientList(HashSet<String> recipients, String subject, String head, String body) {
		for (String r : recipients) {
			dispatchRecipientTyp(r, subject, head, body);
		}
	}

	/**
	 * Method call sendHtml for email recipient and sendSMS for mobile recipient
	 * 
	 * @param recipients
	 * @param subject
	 * @param head
	 * @param body
	 */
	public void dispatchRecipientTyp(String recipients, String subject, String head, String body) {

		if (recipients.contains("+41")) {
			sendSMS(recipients, body);
		} else {
			sendHtml(recipients, subject, head, body);
		}
	}

	/**
	 * Method sends a email to a mail recipient
	 * 
	 * @param recipients
	 * @param subject
	 * @param head
	 * @param body
	 */
	public void sendHtml(String recipients, String subject, String head, String body) {
		String htmlBody = "<h4>" + head + "</h4>" + "<p>" + body + "</p>";
		// Recipient's email ID needs to be mentioned.
		String to = recipients;

		try {
			// Create a default MimeMessage object.
			MimeMessage message = new MimeMessage(session);

			// Set From
			message.setFrom(new InternetAddress(FROM));

			// Set To
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

			// Set Subject
			message.setSubject(subject);

			// set HTML message body
			message.setContent(htmlBody, "text/html");

			// send message
			Transport.send(message);
		} catch (MessagingException e) {
			LOG.error("Error on sending HTML alert: " + e.getMessage());
		}
	}

	/**
	 * Method sends sms to mobile
	 * 
	 * @param recipients
	 * @param body
	 */
	public void sendSMS(String recipients, String body) {
		// Recipient's email ID needs to be mentioned.
		String to = recipients + "@sms.hotelplan.net";
		try {
			// Create a default MimeMessage object.
			MimeMessage message = new MimeMessage(session);

			// Set From
			message.setFrom(new InternetAddress(FROM));

			// Set To
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

			// set SMS message
			message.setText(body);

			// send message
			Transport.send(message);
		} catch (MessagingException e) {
			LOG.error("Error on sending SMS alert: " + e.getMessage());
		}
	}
}