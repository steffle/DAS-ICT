package ppcJobMonitor.Control;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.ExceptionListener;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ppcJobMonitor.Model.Observable;
import ppcJobMonitor.Model.Observer;

/**
 * Class setup a ActiveMQ consumer thread with a ActiveMQ Host and a topic and
 * starts the thread as ExecutorService
 * 
 * @author sflepp
 * @version 1.8
 *
 */
public class AmqMessageProzessor {
	private static final Logger LOG = LoggerFactory.getLogger(AmqMessageProzessor.class);
	private AMQConsumer activeMqConsumer;

	public AmqMessageProzessor(String amqhost, String topic) {
		startConsumerThread(amqhost, topic);
	}

	/**
	 * Method create the AMQConsumer instance and the ExecutorService as
	 * newCachedThreadPool and start the ExecutorService
	 * 
	 * @param amqhost
	 * @param topic
	 */
	public void startConsumerThread(String amqhost, String topic) {
		String activeMqConnectionString = "tcp://" + amqhost + ":61616";
		activeMqConsumer = new AMQConsumer(activeMqConnectionString, topic);
		ExecutorService executorConsumer = Executors.newCachedThreadPool();
		executorConsumer.submit(activeMqConsumer);
		LOG.info("ActiveMQ Connection to " + activeMqConnectionString + " established");
	}

	/**
	 * Method add an observer to the consumer
	 * 
	 * @param Observer
	 */
	public void addObserverToConsumer(Observer observer) {
		activeMqConsumer.addObserver(observer);
	}

	/**
	 * 
	 * Runnable inner Class the ActiveMQ consumer
	 * 
	 * @author sflepp
	 * @param connection,
	 *            topic
	 * 
	 */
	private class AMQConsumer implements Runnable, ExceptionListener, Observable {
		private Observer observer;
		private String connection;
		private String topic;

		private AMQConsumer(String connection, String topic) {
			this.connection = connection;
			this.topic = topic;
		}

		/**
		 * run method setup Connection, Session, Destination and
		 * MessageConsumer. Wait for Message and notifyObervers if is a
		 * TextMessage
		 */
		public void run() {
			try {
				// Create a ConnectionFactory
				ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory("admin", "admin",
						connection);
				// Create a connection
				Connection connection = connectionFactory.createConnection();
				connection.start();

				connection.setExceptionListener(this);

				// Create a Session
				Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

				// Create the destination (Topic)
				Destination destination = session.createTopic(topic);

				// Create a MessageConsumer from the Session to the Topic
				MessageConsumer consumer = session.createConsumer(destination);

				while (true) {
					// Wait for a message
					Message message = consumer.receive();
					if (message instanceof TextMessage) {
						TextMessage textMessage = (TextMessage) message;
						notifyObservers(textMessage.getText());
					} else {
						LOG.debug("Not a TextMessage received");
					}
				}

			} catch (JMSException jmse) {
				LOG.error("JMSException during run: " + jmse.getMessage());
				jmse.printStackTrace();
			} catch (Exception e) {
				LOG.error("Exception during run: " + e.getMessage());
				e.printStackTrace();
			}
		}

		public synchronized void onException(JMSException ex) {
			LOG.error("JMS Exception occured.  Shutting down client." + ex.getMessage());
			ex.printStackTrace();
		}

		public void addObserver(Observer observer) {
			this.observer = observer;

		}

		public void removeObserver(Observer observer) {
			observer = null;

		}

		public void notifyObservers(String msg) {
			observer.update(msg);
		}
	}
}
