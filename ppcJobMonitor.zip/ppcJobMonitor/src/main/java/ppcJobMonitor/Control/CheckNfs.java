package ppcJobMonitor.Control;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ppcJobMonitor.Model.DataAccess;

/**
 * Class checks the enabled log folders for accessibility
 * 
 * @author sflepp
 * @version 1.0.3
 *
 */
public class CheckNfs {
	private static final Logger LOG = LoggerFactory.getLogger(CheckNfs.class);
	private DataAccess dataAccess;
	private ScheduledExecutorService executor;
	private HashSet<String> pathList;
	private boolean alarmed;

	/**
	 * Constructor create path list for checks and newScheduledThreadPool
	 */
	public CheckNfs(DataAccess dataAccess) {
		this.dataAccess = dataAccess;
		setAlarmed(false);
		createPathlist();
		executor = Executors.newScheduledThreadPool(1);
		PathChecker pathChecker = new PathChecker();
		executor.scheduleAtFixedRate((pathChecker), 0L, 15L, TimeUnit.SECONDS);
		LOG.info("NFS-check Thread startet");
	}

	/**
	 * Method get the log-folders as HashSet from DB for all Enviroments an put
	 * that result in the pathlist HashSet
	 */
	public void createPathlist() {
		pathList = dataAccess.getLogPathes();
	}

	public boolean isAlarmed() {
		return alarmed;
	}

	public void setAlarmed(boolean alarmed) {
		this.alarmed = alarmed;
	}

	/**
	 * Runnable inner Class for the actual checking via Files.isReadable(Path)
	 * set alarmed to true after path access errors and sends an alarm
	 * 
	 * @author sflepp
	 *
	 */
	private class PathChecker implements Runnable {

		@Override
		public void run() {
			for (String e : pathList) {
				if (!Files.isReadable(Paths.get(e))) {
					if (!alarmed) {
						new Alert().dispatchRecipientTyp("stefan.flepp@hotelplan.com", "Logfile Path not accessable",
								"CheckNFS Alert", "Path " + e + " not accessable!");
						setAlarmed(true);
						LOG.error("Path: " + e + " not readable!");
					}
				}
			}
		}
	}
}
