package ppcJobMonitor.Model;

import java.sql.*;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class for all data access
 * 
 * @author sflepp
 * @version 1.0.13
 *
 */

public class DataAccess {
	private static final Logger LOG = LoggerFactory.getLogger(DataAccess.class);
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://ch01s7m9.hotelplan.net/ppcjobmon?autoReconnect=true&useSSL=false";
	static final String USER = "monitor";
	static final String PASS = "ZM0exe!xor";
	private Connection connection;
	private HashMap<Integer, String> datatypes;

	/**
	 * Constructor create connection to database
	 */
	public DataAccess() {
		try {
			Class.forName(JDBC_DRIVER);
			connection = DriverManager.getConnection(DB_URL, USER, PASS);
			LOG.info("DB Connection Established with" + DB_URL);
		} catch (ClassNotFoundException cnfe) {
			LOG.error("DataAccess ClassNotFoundException: " + cnfe.getMessage());
		} catch (SQLException sqle) {
			LOG.error("DataAccess SQLException: " + sqle.getMessage());
		}
		createDatatypeMap();
	}

	/**
	 * Method creates a HashMap<Integer, String> for datatype used for
	 * converting integer datatype to string datatype
	 */
	public void createDatatypeMap() {
		datatypes = new HashMap<Integer, String>();
		datatypes.put(1, "HotelOnly");
		datatypes.put(2, "FlightOnly");
		datatypes.put(3, "Package");
	}

	/**
	 * Method return datatype as String
	 * 
	 * @param datatype
	 * @return datatype as String
	 */
	public String getDatatypeAsString(int datatype) {
		return datatypes.get(datatype);
	}

	/**
	 * Method return a HashSet with all log paths from EnvMapping
	 * 
	 * @return all EM_logpath entries
	 */
	public HashSet<String> getLogPathes() {
		ResultSet resultSet = null;
		HashSet<String> result = new HashSet<String>();
		PreparedStatement preparedStatement = null;
		String sql = "SELECT EM_logpath FROM EnvMapping EM LEFT JOIN Enviroment E ON EM.ENV_id = E.ENV_id WHERE ENV_enabled=1;";
		try {
			preparedStatement = connection.prepareStatement(sql);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				result.add(resultSet.getString("EM_logpath"));
			}
			preparedStatement.close();
		} catch (SQLException sqle) {
			LOG.error("DataAccess SQLException: " + sqle.getMessage());
		}
		return result;
	}

	/**
	 * Method return EM_logpath from EnvMapping for a ppcHost
	 * 
	 * @param ppcHost
	 * @return EM_logpath
	 */
	public String getPathFromPpc(String ppcHost) {
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String result = null;
		String sql = "SELECT EM_logpath from EnvMapping where EM_ppchost = ?";
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, ppcHost);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				result = resultSet.getString("EM_logpath");
			}
			preparedStatement.close();
		} catch (SQLException sqle) {
			LOG.error("DataAccess SQLException: " + sqle.getMessage());
		}
		return result;
	}

	/**
	 * Method return the ENV_id from EnvMapping for a ppcHost
	 * 
	 * @param ppcHost
	 * @return ENV_id
	 */
	public int getEnvIdFromPpc(String ppcHost) {
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int result = 0;
		String sql = "SELECT ENV_id from EnvMapping where EM_ppchost = ?";
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, ppcHost);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				result = resultSet.getInt("ENV_id");
			}
			preparedStatement.close();
		} catch (SQLException sqle) {
			LOG.error("DataAccess SQLException: " + sqle.getMessage());
		}
		return result;
	}

	/**
	 * Method return all ENV_amqhost from Enviroment where ENV_enabled = 1
	 * (true)
	 * 
	 * @return ENV_amqhost
	 */
	public HashSet<String> getAmqForEnabledEnvs() {
		ResultSet resultSet = null;
		HashSet<String> result = new HashSet<String>();
		PreparedStatement preparedStatement = null;
		String sql = "SELECT ENV_amqhost from Enviroment WHERE ENV_enabled = 1";
		try {
			preparedStatement = connection.prepareStatement(sql);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				result.add(resultSet.getString("ENV_amqhost"));
			}
			preparedStatement.close();
		} catch (SQLException sqle) {
			LOG.error("DataAccess SQLException: " + sqle.getMessage());
		}
		return result;
	}

	/**
	 * Method return playerCfgId from PlayerCfg with playerId and envId
	 * 
	 * @param playerId
	 * @param envId
	 * @return PlayerCfg_id
	 */
	public int getPlayerCfgId(int playerId, int envId) {
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int result = 0;
		String sql = "SELECT PlayerCfg_id from PlayerCfg where Player_id = ? AND env_id = ?";
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, playerId);
			preparedStatement.setInt(2, envId);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				result = resultSet.getInt("PlayerCfg_id");
			}
			preparedStatement.close();
		} catch (SQLException sqle) {
			LOG.error("DataAccess SQLException: " + sqle.getMessage());
		}
		return result;
	}

	/**
	 * Method return playerCfgId from PlayerCfg with brand, datatype and envId
	 * 
	 * @param brand
	 * @param datatype
	 * @param envId
	 * @return PlayerCfg_id
	 */
	public int getPlayerCfgId(String brand, String datatype, int envId) {
		int playerId = getPlayerId(brand, datatype);
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int result = 0;
		String sql = "SELECT PlayerCfg_id from PlayerCfg where Player_id = ? AND env_id = ?";
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, playerId);
			preparedStatement.setInt(2, envId);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				result = resultSet.getInt("PlayerCfg_id");
			}
			preparedStatement.close();
		} catch (SQLException sqle) {
			LOG.error("DataAccess SQLException: " + sqle.getMessage());
		}
		return result;
	}

	/**
	 * Method return playerId with brand and datatype from Player
	 * 
	 * @param brand
	 * @param datatype
	 * @return Player_id
	 */
	public int getPlayerId(String brand, String datatype) {
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int result = 0;
		String sql = "SELECT Player_id from Player where player_brand = ? AND Player_datatype = ?";
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, brand);
			preparedStatement.setString(2, datatype);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				result = resultSet.getInt("Player_id");
			}
			preparedStatement.close();
		} catch (SQLException sqle) {
			LOG.error("DataAccess SQLException: " + sqle.getMessage());
		}
		return result;
	}

	/**
	 * Method return the newest job timestamp from JobHistory for a PlayerCfgId,
	 * return 0 if no entry found
	 * 
	 * @param playerCfgId
	 * @return JobHist_jobendtime
	 */
	public int getLastHistTimestamp(int playerCfgId) {
		TreeSet<Integer> result = new TreeSet<Integer>();
		ResultSet resultSet = null;
		String sql = "SELECT JobHist_jobendtime, JobHist_objamount FROM JobHistory WHERE PlayerCfg_id = '" + playerCfgId
				+ "' ORDER BY JobHist_jobendtime";
		try {
			Statement stmt = connection.createStatement();
			resultSet = stmt.executeQuery(sql);
			while (resultSet.next()) {
				result.add(resultSet.getInt("JobHist_jobendtime"));
			}

			stmt.close();
		} catch (SQLException sqle) {
			LOG.error("DataAccess SQLException: " + sqle.getMessage());
		}
		if (result.isEmpty()) {
			result.add(0);
		}

		return (Integer) result.last();
	}

	/**
	 * Method return last JobHist_objamount from PlayerCfg with PlayerCfg_id
	 * 
	 * @param playerCfgId
	 * @return JobHist_objamount
	 */
	public int getLastJobResult(int playerCfgId) {
		int lastJobEndTime = getLastHistTimestamp(playerCfgId);
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int result = 0;
		String sql = "SELECT JobHist_objamount FROM JobHistory WHERE PlayerCfg_id = ? AND JobHist_jobendtime = ?";
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, playerCfgId);
			preparedStatement.setInt(2, lastJobEndTime);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				result = resultSet.getInt("JobHist_objamount");
			}
			preparedStatement.close();
		} catch (SQLException sqle) {
			LOG.error("DataAccess SQLException: " + sqle.getMessage());
		}
		return result;
	}

	/**
	 * Method return lower limit from PlayerCfg for a playerCfgId
	 * 
	 * @param playerCfgId
	 * @return PlayerCfg_lower
	 */
	public int getLowerLimit(int playerCfgId) {
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int result = 0;
		String sql = "SELECT PlayerCfg_lower FROM PlayerCfg WHERE PlayerCfg_id = ?";
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, playerCfgId);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				result = resultSet.getInt("PlayerCfg_lower");
			}
			preparedStatement.close();
		} catch (SQLException sqle) {
			LOG.error("DataAccess SQLException: " + sqle.getMessage());
		}
		return result;
	}

	/**
	 * Method return upper limit from PlayerCfg for a playerCfgId
	 * 
	 * @param playerCfgId
	 * @return PlayerCfg_upper
	 */
	public int getUpperLimit(int playerCfgId) {
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int result = 0;
		String sql = "SELECT PlayerCfg_upper FROM PlayerCfg WHERE PlayerCfg_id = ?";
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, playerCfgId);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				result = resultSet.getInt("PlayerCfg_upper");
			}
			preparedStatement.close();
		} catch (SQLException sqle) {
			LOG.error("DataAccess SQLException: " + sqle.getMessage());
		}
		return result;
	}

	/**
	 * Method return a recipient list as HashSet for a PlayerCfg_id
	 * 
	 * @param PlayerCfg_id
	 * @return recipient list with Subscriber_addresses
	 */
	public HashSet<String> getRecipients(int playerCfgId) {
		String sql = "SELECT Subscriber_address FROM NotificationMap N LEFT JOIN NotificationSubscriber NS ON N.Subscriber_id = NS.Subscriber_id WHERE N.NotificationMap_enabled = 1 AND NS.Subscriber_enabled = 1 AND N.PlayerCfg_id = ?";
		ResultSet resultSet = null;
		HashSet<String> result = new HashSet<String>();
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, playerCfgId);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				result.add(resultSet.getString("Subscriber_address"));
			}
			preparedStatement.close();
		} catch (SQLException sqle) {
			LOG.error("DataAccess SQLException: " + sqle.getMessage());
		}
		return result;
	}

	/**
	 * Method insert a new History record in JobHistory with PlayerCfg_id,
	 * JobHist_jobid, JobHist_jobendtime, JobHist_objamount
	 * 
	 * @param playerCfgId
	 * @param jobId
	 * @param jobEnd
	 * @param objAmount
	 */
	public void insertHistoryEntry(int playerCfgId, int jobId, int jobEnd, int objAmount) {
		PreparedStatement preparedStatement = null;
		String sql = "INSERT INTO JobHistory ( PlayerCfg_id, JobHist_jobid, JobHist_jobendtime, JobHist_objamount ) VALUES (?, ?, ?, ?)";
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, playerCfgId);
			preparedStatement.setInt(2, jobId);
			preparedStatement.setInt(3, jobEnd);
			preparedStatement.setInt(4, objAmount);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException sqle) {
			LOG.error("DataAccess SQLException: " + sqle.getMessage());
		}
	}
}
