package ppcJobMonitor.Model;

import java.util.HashSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ppcJobMonitor.Control.Alert;

/**
 * Class for processing the "Constructor finished" messages
 * 
 * @author sflepp
 * @version 1.0.7
 */
public class MsgConstructorFinished {
	private static final Logger LOG = LoggerFactory.getLogger(MsgConstructorFinished.class);
	private int jobId;
	private String brand;
	private String datatype;
	private int playerCfgId;
	private int histTotalObjects;
	private int upperLimit;
	private int lowerLimit;
	private int jobEnd;
	private int totalObjects;
	private boolean jobsucced;
	private DataAccess dataAccess;
	private HashSet<String> recipients;

	/**
	 * Constructor set params and start method processLogfile
	 * 
	 * @param dataAccess
	 * @param path
	 * @param jobId
	 * @param brand
	 * @param datatype
	 * @param modulename
	 * @param jobEnd
	 * @param ppcHost
	 */
	public MsgConstructorFinished(DataAccess dataAccess, String path, int jobId, String brand, String datatype,
			String modulename, int jobEnd, String ppcHost) {
		this.dataAccess = dataAccess;
		this.jobId = jobId;
		this.brand = brand;
		this.datatype = datatype;
		this.jobEnd = jobEnd;
		processLogfile(path, modulename, brand, ppcHost);
	}

	/**
	 * Method create LogfileAnalyzer, set instance variables and runs methods to
	 * compare data, finally write the history
	 */
	public void processLogfile(String path, String modulename, String brand, String ppcHost) {
		String matchStr = ".*._Constructor_.*." + modulename + ".log";
		processLines(path, jobId, matchStr);
		int envId = (dataAccess.getEnvIdFromPpc(ppcHost));
		setPlayerCfgId(dataAccess.getPlayerCfgId(brand, datatype, envId));
		setHistTotalObjects(dataAccess.getLastJobResult(playerCfgId));
		setLowerLimit(dataAccess.getLowerLimit(playerCfgId));
		setUpperLimit(dataAccess.getUpperLimit(playerCfgId));
		setRecipients(dataAccess.getRecipients(playerCfgId));
		compareLastResults();
		writeHistory();
	}

	/**
	 * read last 20 lines and search for Hotel and successfully set the variable
	 * totalObj and jobsucced
	 */
	public void processLines(String path, int jobId, String matchStr) {
		String in = new LogfileContent(path, jobId, matchStr).getLastLines(20);
		String[] lines = in.split("\n");
		try {
			for (String line : lines) {
				try {
					if (line.contains("Hotel")) {
						// substring between pos. of "(" +1 and pos. of ")"
						setTotalObjects(Integer.parseInt(line.substring(line.indexOf("(") + 1, line.indexOf(")"))));
					}
				} catch (Exception e) {
					LOG.error("Error getting totalObjects: " + e.getMessage());
				}
				try {
					if (line.contains("successfully")) {
						setJobsucced(true);
					}
				} catch (Exception e) {
					LOG.error("Error checking getting jobsucced: " + e.getMessage());
				}

			}
		} catch (Exception e) {
			LOG.error("Error processing processLines loop: " + e.getMessage());
		}
	}

	/**
	 * Method compare old and new values and raise if needed a alert
	 */
	public void compareLastResults() {
		// set histTotalObjects and totalObjects even, if no historical data in
		// db
		if (histTotalObjects <= 0) {
			histTotalObjects = totalObjects;
		}
		int diffHistNewAmount = (int) ((totalObjects * 100.0f) / histTotalObjects);
		if (diffHistNewAmount <= lowerLimit) {
			int percent = 100 - diffHistNewAmount;
			String subject = percent + "% weniger Objekte im Preprozess des Player " + brand + " " + datatype;
			String head = "Preprozess Job fuer " + brand + " " + datatype;
			String body = "Job " + jobId + " fuer " + brand + " " + datatype + " endete "
					+ EpochConverter.epochToString(jobEnd) + ". Neu hat es " + totalObjects + ", letzter Job hatte "
					+ histTotalObjects + " Objekte";
			createAlert(subject, head, body);
		}
		if (diffHistNewAmount >= upperLimit) {
			int percent = diffHistNewAmount - 100;
			String subject = percent + "% mehr Objekte im Preprozess des Player " + brand + " " + datatype;
			String head = "Preprozess Job fuer " + brand + " " + datatype;
			String body = "Job " + jobId + " fuer " + brand + " " + datatype + " endete "
					+ EpochConverter.epochToString(jobEnd) + ". Neu hat es " + totalObjects + ", letzter Job hatte "
					+ histTotalObjects + " Objekte";
			createAlert(subject, head, body);
		}
		if (diffHistNewAmount < upperLimit && diffHistNewAmount > lowerLimit) {

		}
	}

	/**
	 * Method call Alert().processList method with HashSet recipients
	 * 
	 * @param subject
	 * @param head
	 * @param body
	 */
	public void createAlert(String subject, String head, String body) {
		if (!recipients.isEmpty()) {
			new Alert().processRecipientList(recipients, subject, head, body);
		}
	}

	/**
	 * Method insert new entry in JobHistory table
	 */
	public void writeHistory() {
		dataAccess.insertHistoryEntry(playerCfgId, jobId, jobEnd, totalObjects);
		LOG.debug("MessageWorker Insert, " + playerCfgId + ", " + jobId + ", " + jobEnd + ", " + totalObjects);
	}

	public int getJobId() {
		return jobId;
	}

	public void setJobId(int jobId) {
		this.jobId = jobId;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getDatatype() {
		return datatype;
	}

	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}

	public int getPlayerCfgId() {
		return playerCfgId;
	}

	public void setPlayerCfgId(int playerCfgId) {
		this.playerCfgId = playerCfgId;
	}

	public int getHistTotalObjects() {
		return histTotalObjects;
	}

	public void setHistTotalObjects(int histTotalObjects) {
		this.histTotalObjects = histTotalObjects;
	}

	public int getUpperLimit() {
		return upperLimit;
	}

	public void setUpperLimit(int upperLimit) {
		this.upperLimit = upperLimit;
	}

	public int getLowerLimit() {
		return lowerLimit;
	}

	public void setLowerLimit(int lowerLimit) {
		this.lowerLimit = lowerLimit;
	}

	public HashSet<String> getRecipients() {
		return recipients;
	}

	public void setRecipients(HashSet<String> recipients) {
		this.recipients = recipients;
	}

	public int getJobEnd() {
		return jobEnd;
	}

	public void setJobEnd(int jobEnd) {
		this.jobEnd = jobEnd;
	}

	public int getTotalObjects() {
		return totalObjects;
	}

	public void setTotalObjects(int totalObjects) {
		this.totalObjects = totalObjects;
	}

	public boolean isJobsucced() {
		return jobsucced;
	}

	public void setJobsucced(boolean jobsucced) {
		this.jobsucced = jobsucced;
	}
}
