package ppcJobMonitor.Model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class get the last lines of a log
 * 
 * @author sflepp
 * @version 1.0.9
 */
public class LogfileContent {
	private static final Logger LOG = LoggerFactory.getLogger(LogfileContent.class);
	private String logfile;

	public LogfileContent(String path, int jobId, String matchStr) {
		setLogfile(findLogFile(path, jobId, matchStr));
	}

	/**
	 * search the directory for matching names, call the method
	 * getLogFileByJobid by matching names
	 * 
	 * @return logfile
	 */
	public String findLogFile(String path, int jobId, String matchStr) {
		File logpath = new File(path);
		File[] files = logpath.listFiles();
		for (File f : files) {
			if (f.toString().matches(matchStr)) {
				if (getLogFileByJobid(f.toString(), jobId)) {
					return f.toString();
				}
			}

		}
		return logfile;
	}

	/**
	 * read the first three lines and checks content for jobid
	 * 
	 * @param logfile,
	 * @return jobid is in file
	 */
	public boolean getLogFileByJobid(String logfile, int jobId) {
		String id = Integer.toString(jobId);
		BufferedReader buffer;
		String line;
		int lineNumber = 0;
		try {
			// create buuferedReader with a FileReader and check 3 first lines
			// for containing jobId
			buffer = new BufferedReader(new FileReader(logfile));
			while (lineNumber < 3) {
				line = buffer.readLine();
				if (line != null && line.contains(id)) {
					buffer.close();
					return true;
				}
				lineNumber++;
			}
			buffer.close();
		} catch (FileNotFoundException fnfe) {
			LOG.error("File not found in getLogFileByJobid: " + fnfe.getMessage());
		} catch (IOException ioe) {
			LOG.error("IOException in getLogFileByJobid: " + ioe.getMessage());
		}
		return false;
	}

	/**
	 * Method read the last n lines from a file
	 * 
	 * @param logfile,
	 *            number of lines
	 * @return n last lines
	 */
	public String getLastLines(int lines) {
		File file = new File(logfile);
		RandomAccessFile fileHandler = null;
		try {
			// create RandomAccesFileHandler with access mode r = readonly
			fileHandler = new RandomAccessFile(file, "r");
			// return lenght of file (-1)
			long fileLength = fileHandler.length() - 1;
			// Creates an empty string builder with a capacity of 16
			StringBuilder stringBuilder = new StringBuilder();
			int line = 0;
			// counting filePointer down to 0
			for (long filePointer = fileLength; filePointer != -1; filePointer--) {
				// setting the filePointer offset, measured from the beginning
				// of this file, at which the next read or write occurs
				fileHandler.seek(filePointer);
				// reading a signed eight-bit value
				int readByte = fileHandler.readByte();
				// if newline
				if (readByte == 0xA) {
					// and if filePointer smaller then fileLength
					if (filePointer < fileLength) {
						line = line + 1;
					}
					// if carriage return
				} else if (readByte == 0xD) {
					// and if filePointer smaller then fileLength
					if (filePointer < fileLength - 1) {
						line = line + 1;
					}
				}
				// if number of lines reached break
				if (line >= lines) {
					break;
				}
				// append character to stringBuilder
				stringBuilder.append((char) readByte);
			}
			// reverse stringBuilder and convert to String
			String lastLine = stringBuilder.reverse().toString();
			return lastLine;
		} catch (FileNotFoundException fnfe) {
			LOG.error("File not found in getLastLines: " + fnfe.getMessage());
			return null;
		} catch (IOException ioe) {
			LOG.error("IOException in getLastLines: " + ioe.getMessage());
			return null;
		} finally {
			if (fileHandler != null)
				try {
					fileHandler.close();
				} catch (IOException e) {
					LOG.error("IOException in getLastLines by closing filehandler: " + e.getMessage());
				}
		}
	}

	public String getLogfile() {
		return logfile;
	}

	public void setLogfile(String logfile) {
		this.logfile = logfile;
	}
}
