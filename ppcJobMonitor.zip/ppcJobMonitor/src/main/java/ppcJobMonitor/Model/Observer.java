package ppcJobMonitor.Model;

public interface Observer {
	void update(String msg);
}
