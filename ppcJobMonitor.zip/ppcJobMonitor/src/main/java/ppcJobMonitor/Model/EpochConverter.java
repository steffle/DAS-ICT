package ppcJobMonitor.Model;

import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * Class return now or an epoch timestamp formated as "yyyy-MM-dd HH:mm:ss"
 * 
 * @author sflepp
 * @version 1.0.1
 *
 */
public class EpochConverter {

	/**
	 * Method convert epoch timestamp to String.
	 * 
	 * @return timestamp
	 */
	public static String epochToString(long epochTs) {
		Date epochDate = new Date(epochTs * 1000L);
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return dateFormat.format(epochDate);
	}

	/**
	 * Method convert now to String
	 * 
	 * @return now as String
	 */
	public static String nowFormated() {
		return epochToString(System.currentTimeMillis() / 1000);
	}
}
